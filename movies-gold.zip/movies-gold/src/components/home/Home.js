import Hero from "../hero/Hero";

function Home({ movies }) {

  if (movies === undefined) {
    return <div>Loading...</div>;
  } else {
    return <Hero movies={movies} />;
  }
  // return <Hero movies = {movies} />;
}

export default Home;
